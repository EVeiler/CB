package com.arifwidayana.challengechapter7.data.local.model.request

data class AuthRequest(
    var username: String?,
    var password: String?
)